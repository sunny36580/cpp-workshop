// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from module_manager_hub:msg/ModuleStatus.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "module_manager_hub/msg/detail/module_status__struct.h"
#include "module_manager_hub/msg/detail/module_status__functions.h"

#include "rosidl_runtime_c/string.h"
#include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool module_manager_hub__msg__module_status__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[51];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("module_manager_hub.msg._module_status.ModuleStatus", full_classname_dest, 50) == 0);
  }
  module_manager_hub__msg__ModuleStatus * ros_message = _ros_message;
  {  // name
    PyObject * field = PyObject_GetAttrString(_pymsg, "name");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->name, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // online
    PyObject * field = PyObject_GetAttrString(_pymsg, "online");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->online = (Py_True == field);
    Py_DECREF(field);
  }
  {  // running
    PyObject * field = PyObject_GetAttrString(_pymsg, "running");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->running = (Py_True == field);
    Py_DECREF(field);
  }
  {  // last_heartbeat
    PyObject * field = PyObject_GetAttrString(_pymsg, "last_heartbeat");
    if (!field) {
      return false;
    }
    assert(PyFloat_Check(field));
    ros_message->last_heartbeat = PyFloat_AS_DOUBLE(field);
    Py_DECREF(field);
  }
  {  // state_msg
    PyObject * field = PyObject_GetAttrString(_pymsg, "state_msg");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->state_msg, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * module_manager_hub__msg__module_status__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ModuleStatus */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("module_manager_hub.msg._module_status");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ModuleStatus");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  module_manager_hub__msg__ModuleStatus * ros_message = (module_manager_hub__msg__ModuleStatus *)raw_ros_message;
  {  // name
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->name.data,
      strlen(ros_message->name.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "name", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // online
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->online ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "online", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // running
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->running ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "running", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // last_heartbeat
    PyObject * field = NULL;
    field = PyFloat_FromDouble(ros_message->last_heartbeat);
    {
      int rc = PyObject_SetAttrString(_pymessage, "last_heartbeat", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // state_msg
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->state_msg.data,
      strlen(ros_message->state_msg.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "state_msg", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
