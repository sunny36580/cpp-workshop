// generated from rosidl_generator_c/resource/idl.h.em
// with input from module_manager_hub:msg/Robotarmcontrol.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__ROBOTARMCONTROL_H_
#define MODULE_MANAGER_HUB__MSG__ROBOTARMCONTROL_H_

#include "module_manager_hub/msg/detail/robotarmcontrol__struct.h"
#include "module_manager_hub/msg/detail/robotarmcontrol__functions.h"
#include "module_manager_hub/msg/detail/robotarmcontrol__type_support.h"

#endif  // MODULE_MANAGER_HUB__MSG__ROBOTARMCONTROL_H_
