// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from module_manager_hub:msg/ModuleStatus.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "module_manager_hub/msg/detail/module_status__rosidl_typesupport_introspection_c.h"
#include "module_manager_hub/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "module_manager_hub/msg/detail/module_status__functions.h"
#include "module_manager_hub/msg/detail/module_status__struct.h"


// Include directives for member types
// Member `name`
// Member `state_msg`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  module_manager_hub__msg__ModuleStatus__init(message_memory);
}

void module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_fini_function(void * message_memory)
{
  module_manager_hub__msg__ModuleStatus__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_message_member_array[5] = {
  {
    "name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub__msg__ModuleStatus, name),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "online",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub__msg__ModuleStatus, online),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "running",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub__msg__ModuleStatus, running),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "last_heartbeat",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub__msg__ModuleStatus, last_heartbeat),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "state_msg",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub__msg__ModuleStatus, state_msg),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_message_members = {
  "module_manager_hub__msg",  // message namespace
  "ModuleStatus",  // message name
  5,  // number of fields
  sizeof(module_manager_hub__msg__ModuleStatus),
  module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_message_member_array,  // message members
  module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_init_function,  // function to initialize message memory (memory has to be allocated)
  module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_message_type_support_handle = {
  0,
  &module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_module_manager_hub
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, module_manager_hub, msg, ModuleStatus)() {
  if (!module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_message_type_support_handle.typesupport_identifier) {
    module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &module_manager_hub__msg__ModuleStatus__rosidl_typesupport_introspection_c__ModuleStatus_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
