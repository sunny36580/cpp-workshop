// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from module_manager_hub:msg/Robotarmcontrol.idl
// generated code does not contain a copyright notice
#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "module_manager_hub/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_module_manager_hub
size_t get_serialized_size_module_manager_hub__msg__Robotarmcontrol(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_module_manager_hub
size_t max_serialized_size_module_manager_hub__msg__Robotarmcontrol(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_module_manager_hub
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, module_manager_hub, msg, Robotarmcontrol)();

#ifdef __cplusplus
}
#endif

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
