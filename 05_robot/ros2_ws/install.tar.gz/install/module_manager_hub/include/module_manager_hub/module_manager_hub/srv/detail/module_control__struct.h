﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from module_manager_hub:srv/ModuleControl.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__STRUCT_H_
#define MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'module_name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/ModuleControl in the package module_manager_hub.
typedef struct module_manager_hub__srv__ModuleControl_Request
{
  rosidl_runtime_c__String module_name;
  /// 1启动 2停止 3重启 4禁用
  uint8_t cmd;
} module_manager_hub__srv__ModuleControl_Request;

// Struct for a sequence of module_manager_hub__srv__ModuleControl_Request.
typedef struct module_manager_hub__srv__ModuleControl_Request__Sequence
{
  module_manager_hub__srv__ModuleControl_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} module_manager_hub__srv__ModuleControl_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/ModuleControl in the package module_manager_hub.
typedef struct module_manager_hub__srv__ModuleControl_Response
{
  bool success;
  rosidl_runtime_c__String message;
} module_manager_hub__srv__ModuleControl_Response;

// Struct for a sequence of module_manager_hub__srv__ModuleControl_Response.
typedef struct module_manager_hub__srv__ModuleControl_Response__Sequence
{
  module_manager_hub__srv__ModuleControl_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} module_manager_hub__srv__ModuleControl_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__STRUCT_H_
