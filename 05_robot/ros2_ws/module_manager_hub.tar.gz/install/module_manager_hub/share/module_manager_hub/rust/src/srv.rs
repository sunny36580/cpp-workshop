#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};




// Corresponds to module_manager_hub__srv__ModuleControl_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ModuleControl_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub module_name: std::string::String,

    /// 1启动 2停止 3重启 4禁用
    pub cmd: u8,

}



impl Default for ModuleControl_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ModuleControl_Request::default())
  }
}

impl rosidl_runtime_rs::Message for ModuleControl_Request {
  type RmwMsg = super::srv::rmw::ModuleControl_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        module_name: msg.module_name.as_str().into(),
        cmd: msg.cmd,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        module_name: msg.module_name.as_str().into(),
      cmd: msg.cmd,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      module_name: msg.module_name.to_string(),
      cmd: msg.cmd,
    }
  }
}


// Corresponds to module_manager_hub__srv__ModuleControl_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ModuleControl_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for ModuleControl_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::ModuleControl_Response::default())
  }
}

impl rosidl_runtime_rs::Message for ModuleControl_Response {
  type RmwMsg = super::srv::rmw::ModuleControl_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}






#[link(name = "module_manager_hub__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__module_manager_hub__srv__ModuleControl() -> *const std::ffi::c_void;
}

// Corresponds to module_manager_hub__srv__ModuleControl
#[allow(missing_docs, non_camel_case_types)]
pub struct ModuleControl;

impl rosidl_runtime_rs::Service for ModuleControl {
    type Request = ModuleControl_Request;
    type Response = ModuleControl_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__module_manager_hub__srv__ModuleControl() }
    }
}


