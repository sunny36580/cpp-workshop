// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from module_manager_hub:srv/ModuleControl.idl
// generated code does not contain a copyright notice
#include "module_manager_hub/srv/detail/module_control__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `module_name`
#include "rosidl_runtime_c/string_functions.h"

bool
module_manager_hub__srv__ModuleControl_Request__init(module_manager_hub__srv__ModuleControl_Request * msg)
{
  if (!msg) {
    return false;
  }
  // module_name
  if (!rosidl_runtime_c__String__init(&msg->module_name)) {
    module_manager_hub__srv__ModuleControl_Request__fini(msg);
    return false;
  }
  // cmd
  return true;
}

void
module_manager_hub__srv__ModuleControl_Request__fini(module_manager_hub__srv__ModuleControl_Request * msg)
{
  if (!msg) {
    return;
  }
  // module_name
  rosidl_runtime_c__String__fini(&msg->module_name);
  // cmd
}

bool
module_manager_hub__srv__ModuleControl_Request__are_equal(const module_manager_hub__srv__ModuleControl_Request * lhs, const module_manager_hub__srv__ModuleControl_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // module_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->module_name), &(rhs->module_name)))
  {
    return false;
  }
  // cmd
  if (lhs->cmd != rhs->cmd) {
    return false;
  }
  return true;
}

bool
module_manager_hub__srv__ModuleControl_Request__copy(
  const module_manager_hub__srv__ModuleControl_Request * input,
  module_manager_hub__srv__ModuleControl_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // module_name
  if (!rosidl_runtime_c__String__copy(
      &(input->module_name), &(output->module_name)))
  {
    return false;
  }
  // cmd
  output->cmd = input->cmd;
  return true;
}

module_manager_hub__srv__ModuleControl_Request *
module_manager_hub__srv__ModuleControl_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__srv__ModuleControl_Request * msg = (module_manager_hub__srv__ModuleControl_Request *)allocator.allocate(sizeof(module_manager_hub__srv__ModuleControl_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(module_manager_hub__srv__ModuleControl_Request));
  bool success = module_manager_hub__srv__ModuleControl_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
module_manager_hub__srv__ModuleControl_Request__destroy(module_manager_hub__srv__ModuleControl_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    module_manager_hub__srv__ModuleControl_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
module_manager_hub__srv__ModuleControl_Request__Sequence__init(module_manager_hub__srv__ModuleControl_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__srv__ModuleControl_Request * data = NULL;

  if (size) {
    data = (module_manager_hub__srv__ModuleControl_Request *)allocator.zero_allocate(size, sizeof(module_manager_hub__srv__ModuleControl_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = module_manager_hub__srv__ModuleControl_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        module_manager_hub__srv__ModuleControl_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
module_manager_hub__srv__ModuleControl_Request__Sequence__fini(module_manager_hub__srv__ModuleControl_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      module_manager_hub__srv__ModuleControl_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

module_manager_hub__srv__ModuleControl_Request__Sequence *
module_manager_hub__srv__ModuleControl_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__srv__ModuleControl_Request__Sequence * array = (module_manager_hub__srv__ModuleControl_Request__Sequence *)allocator.allocate(sizeof(module_manager_hub__srv__ModuleControl_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = module_manager_hub__srv__ModuleControl_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
module_manager_hub__srv__ModuleControl_Request__Sequence__destroy(module_manager_hub__srv__ModuleControl_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    module_manager_hub__srv__ModuleControl_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
module_manager_hub__srv__ModuleControl_Request__Sequence__are_equal(const module_manager_hub__srv__ModuleControl_Request__Sequence * lhs, const module_manager_hub__srv__ModuleControl_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!module_manager_hub__srv__ModuleControl_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
module_manager_hub__srv__ModuleControl_Request__Sequence__copy(
  const module_manager_hub__srv__ModuleControl_Request__Sequence * input,
  module_manager_hub__srv__ModuleControl_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(module_manager_hub__srv__ModuleControl_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    module_manager_hub__srv__ModuleControl_Request * data =
      (module_manager_hub__srv__ModuleControl_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!module_manager_hub__srv__ModuleControl_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          module_manager_hub__srv__ModuleControl_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!module_manager_hub__srv__ModuleControl_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `message`
// already included above
// #include "rosidl_runtime_c/string_functions.h"

bool
module_manager_hub__srv__ModuleControl_Response__init(module_manager_hub__srv__ModuleControl_Response * msg)
{
  if (!msg) {
    return false;
  }
  // success
  // message
  if (!rosidl_runtime_c__String__init(&msg->message)) {
    module_manager_hub__srv__ModuleControl_Response__fini(msg);
    return false;
  }
  return true;
}

void
module_manager_hub__srv__ModuleControl_Response__fini(module_manager_hub__srv__ModuleControl_Response * msg)
{
  if (!msg) {
    return;
  }
  // success
  // message
  rosidl_runtime_c__String__fini(&msg->message);
}

bool
module_manager_hub__srv__ModuleControl_Response__are_equal(const module_manager_hub__srv__ModuleControl_Response * lhs, const module_manager_hub__srv__ModuleControl_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // success
  if (lhs->success != rhs->success) {
    return false;
  }
  // message
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->message), &(rhs->message)))
  {
    return false;
  }
  return true;
}

bool
module_manager_hub__srv__ModuleControl_Response__copy(
  const module_manager_hub__srv__ModuleControl_Response * input,
  module_manager_hub__srv__ModuleControl_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // success
  output->success = input->success;
  // message
  if (!rosidl_runtime_c__String__copy(
      &(input->message), &(output->message)))
  {
    return false;
  }
  return true;
}

module_manager_hub__srv__ModuleControl_Response *
module_manager_hub__srv__ModuleControl_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__srv__ModuleControl_Response * msg = (module_manager_hub__srv__ModuleControl_Response *)allocator.allocate(sizeof(module_manager_hub__srv__ModuleControl_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(module_manager_hub__srv__ModuleControl_Response));
  bool success = module_manager_hub__srv__ModuleControl_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
module_manager_hub__srv__ModuleControl_Response__destroy(module_manager_hub__srv__ModuleControl_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    module_manager_hub__srv__ModuleControl_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
module_manager_hub__srv__ModuleControl_Response__Sequence__init(module_manager_hub__srv__ModuleControl_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__srv__ModuleControl_Response * data = NULL;

  if (size) {
    data = (module_manager_hub__srv__ModuleControl_Response *)allocator.zero_allocate(size, sizeof(module_manager_hub__srv__ModuleControl_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = module_manager_hub__srv__ModuleControl_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        module_manager_hub__srv__ModuleControl_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
module_manager_hub__srv__ModuleControl_Response__Sequence__fini(module_manager_hub__srv__ModuleControl_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      module_manager_hub__srv__ModuleControl_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

module_manager_hub__srv__ModuleControl_Response__Sequence *
module_manager_hub__srv__ModuleControl_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__srv__ModuleControl_Response__Sequence * array = (module_manager_hub__srv__ModuleControl_Response__Sequence *)allocator.allocate(sizeof(module_manager_hub__srv__ModuleControl_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = module_manager_hub__srv__ModuleControl_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
module_manager_hub__srv__ModuleControl_Response__Sequence__destroy(module_manager_hub__srv__ModuleControl_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    module_manager_hub__srv__ModuleControl_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
module_manager_hub__srv__ModuleControl_Response__Sequence__are_equal(const module_manager_hub__srv__ModuleControl_Response__Sequence * lhs, const module_manager_hub__srv__ModuleControl_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!module_manager_hub__srv__ModuleControl_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
module_manager_hub__srv__ModuleControl_Response__Sequence__copy(
  const module_manager_hub__srv__ModuleControl_Response__Sequence * input,
  module_manager_hub__srv__ModuleControl_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(module_manager_hub__srv__ModuleControl_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    module_manager_hub__srv__ModuleControl_Response * data =
      (module_manager_hub__srv__ModuleControl_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!module_manager_hub__srv__ModuleControl_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          module_manager_hub__srv__ModuleControl_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!module_manager_hub__srv__ModuleControl_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
