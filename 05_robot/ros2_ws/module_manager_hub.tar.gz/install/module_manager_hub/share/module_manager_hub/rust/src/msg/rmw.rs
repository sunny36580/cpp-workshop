#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "module_manager_hub__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__msg__ModuleStatus() -> *const std::ffi::c_void;
}

#[link(name = "module_manager_hub__rosidl_generator_c")]
extern "C" {
    fn module_manager_hub__msg__ModuleStatus__init(msg: *mut ModuleStatus) -> bool;
    fn module_manager_hub__msg__ModuleStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ModuleStatus>, size: usize) -> bool;
    fn module_manager_hub__msg__ModuleStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ModuleStatus>);
    fn module_manager_hub__msg__ModuleStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ModuleStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<ModuleStatus>) -> bool;
}

// Corresponds to module_manager_hub__msg__ModuleStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ModuleStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub online: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub running: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub last_heartbeat: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub state_msg: rosidl_runtime_rs::String,

}



impl Default for ModuleStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !module_manager_hub__msg__ModuleStatus__init(&mut msg as *mut _) {
        panic!("Call to module_manager_hub__msg__ModuleStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ModuleStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__msg__ModuleStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__msg__ModuleStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__msg__ModuleStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ModuleStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ModuleStatus where Self: Sized {
  const TYPE_NAME: &'static str = "module_manager_hub/msg/ModuleStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__msg__ModuleStatus() }
  }
}


#[link(name = "module_manager_hub__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__msg__Robotarmcontrol() -> *const std::ffi::c_void;
}

#[link(name = "module_manager_hub__rosidl_generator_c")]
extern "C" {
    fn module_manager_hub__msg__Robotarmcontrol__init(msg: *mut Robotarmcontrol) -> bool;
    fn module_manager_hub__msg__Robotarmcontrol__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Robotarmcontrol>, size: usize) -> bool;
    fn module_manager_hub__msg__Robotarmcontrol__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Robotarmcontrol>);
    fn module_manager_hub__msg__Robotarmcontrol__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Robotarmcontrol>, out_seq: *mut rosidl_runtime_rs::Sequence<Robotarmcontrol>) -> bool;
}

// Corresponds to module_manager_hub__msg__Robotarmcontrol
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// 机械臂控制消息

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Robotarmcontrol {

    // This member is not documented.
    #[allow(missing_docs)]
    pub motor_ids: rosidl_runtime_rs::Sequence<u32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_positions: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_velocitie: rosidl_runtime_rs::Sequence<f32>,

}



impl Default for Robotarmcontrol {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !module_manager_hub__msg__Robotarmcontrol__init(&mut msg as *mut _) {
        panic!("Call to module_manager_hub__msg__Robotarmcontrol__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Robotarmcontrol {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__msg__Robotarmcontrol__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__msg__Robotarmcontrol__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__msg__Robotarmcontrol__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Robotarmcontrol {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Robotarmcontrol where Self: Sized {
  const TYPE_NAME: &'static str = "module_manager_hub/msg/Robotarmcontrol";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__msg__Robotarmcontrol() }
  }
}


#[link(name = "module_manager_hub__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__msg__Robotarmstatus() -> *const std::ffi::c_void;
}

#[link(name = "module_manager_hub__rosidl_generator_c")]
extern "C" {
    fn module_manager_hub__msg__Robotarmstatus__init(msg: *mut Robotarmstatus) -> bool;
    fn module_manager_hub__msg__Robotarmstatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Robotarmstatus>, size: usize) -> bool;
    fn module_manager_hub__msg__Robotarmstatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Robotarmstatus>);
    fn module_manager_hub__msg__Robotarmstatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Robotarmstatus>, out_seq: *mut rosidl_runtime_rs::Sequence<Robotarmstatus>) -> bool;
}

// Corresponds to module_manager_hub__msg__Robotarmstatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// 机械臂状态消息

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Robotarmstatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub motor_ids: rosidl_runtime_rs::Sequence<u32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_positions: rosidl_runtime_rs::Sequence<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_velocities: rosidl_runtime_rs::Sequence<f32>,

}



impl Default for Robotarmstatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !module_manager_hub__msg__Robotarmstatus__init(&mut msg as *mut _) {
        panic!("Call to module_manager_hub__msg__Robotarmstatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Robotarmstatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__msg__Robotarmstatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__msg__Robotarmstatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__msg__Robotarmstatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Robotarmstatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Robotarmstatus where Self: Sized {
  const TYPE_NAME: &'static str = "module_manager_hub/msg/Robotarmstatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__msg__Robotarmstatus() }
  }
}


