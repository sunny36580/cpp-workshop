// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from module_manager_hub:msg/ModuleStatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__BUILDER_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "module_manager_hub/msg/detail/module_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace module_manager_hub
{

namespace msg
{

namespace builder
{

class Init_ModuleStatus_state_msg
{
public:
  explicit Init_ModuleStatus_state_msg(::module_manager_hub::msg::ModuleStatus & msg)
  : msg_(msg)
  {}
  ::module_manager_hub::msg::ModuleStatus state_msg(::module_manager_hub::msg::ModuleStatus::_state_msg_type arg)
  {
    msg_.state_msg = std::move(arg);
    return std::move(msg_);
  }

private:
  ::module_manager_hub::msg::ModuleStatus msg_;
};

class Init_ModuleStatus_last_heartbeat
{
public:
  explicit Init_ModuleStatus_last_heartbeat(::module_manager_hub::msg::ModuleStatus & msg)
  : msg_(msg)
  {}
  Init_ModuleStatus_state_msg last_heartbeat(::module_manager_hub::msg::ModuleStatus::_last_heartbeat_type arg)
  {
    msg_.last_heartbeat = std::move(arg);
    return Init_ModuleStatus_state_msg(msg_);
  }

private:
  ::module_manager_hub::msg::ModuleStatus msg_;
};

class Init_ModuleStatus_running
{
public:
  explicit Init_ModuleStatus_running(::module_manager_hub::msg::ModuleStatus & msg)
  : msg_(msg)
  {}
  Init_ModuleStatus_last_heartbeat running(::module_manager_hub::msg::ModuleStatus::_running_type arg)
  {
    msg_.running = std::move(arg);
    return Init_ModuleStatus_last_heartbeat(msg_);
  }

private:
  ::module_manager_hub::msg::ModuleStatus msg_;
};

class Init_ModuleStatus_online
{
public:
  explicit Init_ModuleStatus_online(::module_manager_hub::msg::ModuleStatus & msg)
  : msg_(msg)
  {}
  Init_ModuleStatus_running online(::module_manager_hub::msg::ModuleStatus::_online_type arg)
  {
    msg_.online = std::move(arg);
    return Init_ModuleStatus_running(msg_);
  }

private:
  ::module_manager_hub::msg::ModuleStatus msg_;
};

class Init_ModuleStatus_name
{
public:
  Init_ModuleStatus_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ModuleStatus_online name(::module_manager_hub::msg::ModuleStatus::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_ModuleStatus_online(msg_);
  }

private:
  ::module_manager_hub::msg::ModuleStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::module_manager_hub::msg::ModuleStatus>()
{
  return module_manager_hub::msg::builder::Init_ModuleStatus_name();
}

}  // namespace module_manager_hub

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__BUILDER_HPP_
