#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



#[link(name = "module_manager_hub__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__srv__ModuleControl_Request() -> *const std::ffi::c_void;
}

#[link(name = "module_manager_hub__rosidl_generator_c")]
extern "C" {
    fn module_manager_hub__srv__ModuleControl_Request__init(msg: *mut ModuleControl_Request) -> bool;
    fn module_manager_hub__srv__ModuleControl_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ModuleControl_Request>, size: usize) -> bool;
    fn module_manager_hub__srv__ModuleControl_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ModuleControl_Request>);
    fn module_manager_hub__srv__ModuleControl_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ModuleControl_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ModuleControl_Request>) -> bool;
}

// Corresponds to module_manager_hub__srv__ModuleControl_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ModuleControl_Request {

    // This member is not documented.
    #[allow(missing_docs)]
    pub module_name: rosidl_runtime_rs::String,

    /// 1启动 2停止 3重启 4禁用
    pub cmd: u8,

}



impl Default for ModuleControl_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !module_manager_hub__srv__ModuleControl_Request__init(&mut msg as *mut _) {
        panic!("Call to module_manager_hub__srv__ModuleControl_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ModuleControl_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__srv__ModuleControl_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__srv__ModuleControl_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__srv__ModuleControl_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ModuleControl_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ModuleControl_Request where Self: Sized {
  const TYPE_NAME: &'static str = "module_manager_hub/srv/ModuleControl_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__srv__ModuleControl_Request() }
  }
}


#[link(name = "module_manager_hub__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__srv__ModuleControl_Response() -> *const std::ffi::c_void;
}

#[link(name = "module_manager_hub__rosidl_generator_c")]
extern "C" {
    fn module_manager_hub__srv__ModuleControl_Response__init(msg: *mut ModuleControl_Response) -> bool;
    fn module_manager_hub__srv__ModuleControl_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ModuleControl_Response>, size: usize) -> bool;
    fn module_manager_hub__srv__ModuleControl_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ModuleControl_Response>);
    fn module_manager_hub__srv__ModuleControl_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ModuleControl_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ModuleControl_Response>) -> bool;
}

// Corresponds to module_manager_hub__srv__ModuleControl_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ModuleControl_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for ModuleControl_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !module_manager_hub__srv__ModuleControl_Response__init(&mut msg as *mut _) {
        panic!("Call to module_manager_hub__srv__ModuleControl_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ModuleControl_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__srv__ModuleControl_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__srv__ModuleControl_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { module_manager_hub__srv__ModuleControl_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ModuleControl_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ModuleControl_Response where Self: Sized {
  const TYPE_NAME: &'static str = "module_manager_hub/srv/ModuleControl_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__module_manager_hub__srv__ModuleControl_Response() }
  }
}






#[link(name = "module_manager_hub__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__module_manager_hub__srv__ModuleControl() -> *const std::ffi::c_void;
}

// Corresponds to module_manager_hub__srv__ModuleControl
#[allow(missing_docs, non_camel_case_types)]
pub struct ModuleControl;

impl rosidl_runtime_rs::Service for ModuleControl {
    type Request = ModuleControl_Request;
    type Response = ModuleControl_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__module_manager_hub__srv__ModuleControl() }
    }
}


