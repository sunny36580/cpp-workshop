// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__MODULE_STATUS_HPP_
#define MODULE_MANAGER_HUB__MSG__MODULE_STATUS_HPP_

#include "module_manager_hub/msg/detail/module_status__struct.hpp"
#include "module_manager_hub/msg/detail/module_status__builder.hpp"
#include "module_manager_hub/msg/detail/module_status__traits.hpp"
#include "module_manager_hub/msg/detail/module_status__type_support.hpp"

#endif  // MODULE_MANAGER_HUB__MSG__MODULE_STATUS_HPP_
