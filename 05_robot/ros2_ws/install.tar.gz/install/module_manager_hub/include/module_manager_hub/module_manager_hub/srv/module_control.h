// generated from rosidl_generator_c/resource/idl.h.em
// with input from module_manager_hub:srv/ModuleControl.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__SRV__MODULE_CONTROL_H_
#define MODULE_MANAGER_HUB__SRV__MODULE_CONTROL_H_

#include "module_manager_hub/srv/detail/module_control__struct.h"
#include "module_manager_hub/srv/detail/module_control__functions.h"
#include "module_manager_hub/srv/detail/module_control__type_support.h"

#endif  // MODULE_MANAGER_HUB__SRV__MODULE_CONTROL_H_
