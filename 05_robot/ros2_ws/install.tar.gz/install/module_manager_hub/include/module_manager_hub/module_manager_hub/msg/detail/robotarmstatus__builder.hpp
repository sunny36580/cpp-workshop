// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from module_manager_hub:msg/Robotarmstatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__BUILDER_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "module_manager_hub/msg/detail/robotarmstatus__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace module_manager_hub
{

namespace msg
{

namespace builder
{

class Init_Robotarmstatus_actual_velocities
{
public:
  explicit Init_Robotarmstatus_actual_velocities(::module_manager_hub::msg::Robotarmstatus & msg)
  : msg_(msg)
  {}
  ::module_manager_hub::msg::Robotarmstatus actual_velocities(::module_manager_hub::msg::Robotarmstatus::_actual_velocities_type arg)
  {
    msg_.actual_velocities = std::move(arg);
    return std::move(msg_);
  }

private:
  ::module_manager_hub::msg::Robotarmstatus msg_;
};

class Init_Robotarmstatus_actual_positions
{
public:
  explicit Init_Robotarmstatus_actual_positions(::module_manager_hub::msg::Robotarmstatus & msg)
  : msg_(msg)
  {}
  Init_Robotarmstatus_actual_velocities actual_positions(::module_manager_hub::msg::Robotarmstatus::_actual_positions_type arg)
  {
    msg_.actual_positions = std::move(arg);
    return Init_Robotarmstatus_actual_velocities(msg_);
  }

private:
  ::module_manager_hub::msg::Robotarmstatus msg_;
};

class Init_Robotarmstatus_motor_ids
{
public:
  Init_Robotarmstatus_motor_ids()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Robotarmstatus_actual_positions motor_ids(::module_manager_hub::msg::Robotarmstatus::_motor_ids_type arg)
  {
    msg_.motor_ids = std::move(arg);
    return Init_Robotarmstatus_actual_positions(msg_);
  }

private:
  ::module_manager_hub::msg::Robotarmstatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::module_manager_hub::msg::Robotarmstatus>()
{
  return module_manager_hub::msg::builder::Init_Robotarmstatus_motor_ids();
}

}  // namespace module_manager_hub

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__BUILDER_HPP_
