﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from module_manager_hub:msg/Robotarmcontrol.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__STRUCT_H_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'motor_ids'
// Member 'target_positions'
// Member 'target_velocitie'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/Robotarmcontrol in the package module_manager_hub.
/**
  * 机械臂控制消息
 */
typedef struct module_manager_hub__msg__Robotarmcontrol
{
  rosidl_runtime_c__uint32__Sequence motor_ids;
  rosidl_runtime_c__float__Sequence target_positions;
  rosidl_runtime_c__float__Sequence target_velocitie;
} module_manager_hub__msg__Robotarmcontrol;

// Struct for a sequence of module_manager_hub__msg__Robotarmcontrol.
typedef struct module_manager_hub__msg__Robotarmcontrol__Sequence
{
  module_manager_hub__msg__Robotarmcontrol * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} module_manager_hub__msg__Robotarmcontrol__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__STRUCT_H_
