// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from module_manager_hub:msg/Robotarmcontrol.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "module_manager_hub/msg/detail/robotarmcontrol__rosidl_typesupport_introspection_c.h"
#include "module_manager_hub/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "module_manager_hub/msg/detail/robotarmcontrol__functions.h"
#include "module_manager_hub/msg/detail/robotarmcontrol__struct.h"


// Include directives for member types
// Member `motor_ids`
// Member `target_positions`
// Member `target_velocitie`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  module_manager_hub__msg__Robotarmcontrol__init(message_memory);
}

void module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_fini_function(void * message_memory)
{
  module_manager_hub__msg__Robotarmcontrol__fini(message_memory);
}

size_t module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__size_function__Robotarmcontrol__motor_ids(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return member->size;
}

const void * module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_const_function__Robotarmcontrol__motor_ids(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void * module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_function__Robotarmcontrol__motor_ids(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__fetch_function__Robotarmcontrol__motor_ids(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint32_t * item =
    ((const uint32_t *)
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_const_function__Robotarmcontrol__motor_ids(untyped_member, index));
  uint32_t * value =
    (uint32_t *)(untyped_value);
  *value = *item;
}

void module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__assign_function__Robotarmcontrol__motor_ids(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint32_t * item =
    ((uint32_t *)
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_function__Robotarmcontrol__motor_ids(untyped_member, index));
  const uint32_t * value =
    (const uint32_t *)(untyped_value);
  *item = *value;
}

bool module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__resize_function__Robotarmcontrol__motor_ids(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  rosidl_runtime_c__uint32__Sequence__fini(member);
  return rosidl_runtime_c__uint32__Sequence__init(member, size);
}

size_t module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__size_function__Robotarmcontrol__target_positions(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_const_function__Robotarmcontrol__target_positions(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_function__Robotarmcontrol__target_positions(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__fetch_function__Robotarmcontrol__target_positions(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_const_function__Robotarmcontrol__target_positions(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__assign_function__Robotarmcontrol__target_positions(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_function__Robotarmcontrol__target_positions(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__resize_function__Robotarmcontrol__target_positions(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__size_function__Robotarmcontrol__target_velocitie(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_const_function__Robotarmcontrol__target_velocitie(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_function__Robotarmcontrol__target_velocitie(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__fetch_function__Robotarmcontrol__target_velocitie(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_const_function__Robotarmcontrol__target_velocitie(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__assign_function__Robotarmcontrol__target_velocitie(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_function__Robotarmcontrol__target_velocitie(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__resize_function__Robotarmcontrol__target_velocitie(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_message_member_array[3] = {
  {
    "motor_ids",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub__msg__Robotarmcontrol, motor_ids),  // bytes offset in struct
    NULL,  // default value
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__size_function__Robotarmcontrol__motor_ids,  // size() function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_const_function__Robotarmcontrol__motor_ids,  // get_const(index) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_function__Robotarmcontrol__motor_ids,  // get(index) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__fetch_function__Robotarmcontrol__motor_ids,  // fetch(index, &value) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__assign_function__Robotarmcontrol__motor_ids,  // assign(index, value) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__resize_function__Robotarmcontrol__motor_ids  // resize(index) function pointer
  },
  {
    "target_positions",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub__msg__Robotarmcontrol, target_positions),  // bytes offset in struct
    NULL,  // default value
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__size_function__Robotarmcontrol__target_positions,  // size() function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_const_function__Robotarmcontrol__target_positions,  // get_const(index) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_function__Robotarmcontrol__target_positions,  // get(index) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__fetch_function__Robotarmcontrol__target_positions,  // fetch(index, &value) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__assign_function__Robotarmcontrol__target_positions,  // assign(index, value) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__resize_function__Robotarmcontrol__target_positions  // resize(index) function pointer
  },
  {
    "target_velocitie",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub__msg__Robotarmcontrol, target_velocitie),  // bytes offset in struct
    NULL,  // default value
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__size_function__Robotarmcontrol__target_velocitie,  // size() function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_const_function__Robotarmcontrol__target_velocitie,  // get_const(index) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__get_function__Robotarmcontrol__target_velocitie,  // get(index) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__fetch_function__Robotarmcontrol__target_velocitie,  // fetch(index, &value) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__assign_function__Robotarmcontrol__target_velocitie,  // assign(index, value) function pointer
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__resize_function__Robotarmcontrol__target_velocitie  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_message_members = {
  "module_manager_hub__msg",  // message namespace
  "Robotarmcontrol",  // message name
  3,  // number of fields
  sizeof(module_manager_hub__msg__Robotarmcontrol),
  module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_message_member_array,  // message members
  module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_init_function,  // function to initialize message memory (memory has to be allocated)
  module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_message_type_support_handle = {
  0,
  &module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_module_manager_hub
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, module_manager_hub, msg, Robotarmcontrol)() {
  if (!module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_message_type_support_handle.typesupport_identifier) {
    module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &module_manager_hub__msg__Robotarmcontrol__rosidl_typesupport_introspection_c__Robotarmcontrol_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
