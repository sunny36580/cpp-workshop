// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from module_manager_hub:msg/Robotarmcontrol.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__STRUCT_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__module_manager_hub__msg__Robotarmcontrol __attribute__((deprecated))
#else
# define DEPRECATED__module_manager_hub__msg__Robotarmcontrol __declspec(deprecated)
#endif

namespace module_manager_hub
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Robotarmcontrol_
{
  using Type = Robotarmcontrol_<ContainerAllocator>;

  explicit Robotarmcontrol_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
  }

  explicit Robotarmcontrol_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
    (void)_alloc;
  }

  // field types and members
  using _motor_ids_type =
    std::vector<uint32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint32_t>>;
  _motor_ids_type motor_ids;
  using _target_positions_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _target_positions_type target_positions;
  using _target_velocitie_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _target_velocitie_type target_velocitie;

  // setters for named parameter idiom
  Type & set__motor_ids(
    const std::vector<uint32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint32_t>> & _arg)
  {
    this->motor_ids = _arg;
    return *this;
  }
  Type & set__target_positions(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->target_positions = _arg;
    return *this;
  }
  Type & set__target_velocitie(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->target_velocitie = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator> *;
  using ConstRawPtr =
    const module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__module_manager_hub__msg__Robotarmcontrol
    std::shared_ptr<module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__module_manager_hub__msg__Robotarmcontrol
    std::shared_ptr<module_manager_hub::msg::Robotarmcontrol_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Robotarmcontrol_ & other) const
  {
    if (this->motor_ids != other.motor_ids) {
      return false;
    }
    if (this->target_positions != other.target_positions) {
      return false;
    }
    if (this->target_velocitie != other.target_velocitie) {
      return false;
    }
    return true;
  }
  bool operator!=(const Robotarmcontrol_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Robotarmcontrol_

// alias to use template instance with default allocator
using Robotarmcontrol =
  module_manager_hub::msg::Robotarmcontrol_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace module_manager_hub

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__STRUCT_HPP_
