// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from module_manager_hub:msg/Robotarmcontrol.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__TRAITS_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "module_manager_hub/msg/detail/robotarmcontrol__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace module_manager_hub
{

namespace msg
{

inline void to_flow_style_yaml(
  const Robotarmcontrol & msg,
  std::ostream & out)
{
  out << "{";
  // member: motor_ids
  {
    if (msg.motor_ids.size() == 0) {
      out << "motor_ids: []";
    } else {
      out << "motor_ids: [";
      size_t pending_items = msg.motor_ids.size();
      for (auto item : msg.motor_ids) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: target_positions
  {
    if (msg.target_positions.size() == 0) {
      out << "target_positions: []";
    } else {
      out << "target_positions: [";
      size_t pending_items = msg.target_positions.size();
      for (auto item : msg.target_positions) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: target_velocitie
  {
    if (msg.target_velocitie.size() == 0) {
      out << "target_velocitie: []";
    } else {
      out << "target_velocitie: [";
      size_t pending_items = msg.target_velocitie.size();
      for (auto item : msg.target_velocitie) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Robotarmcontrol & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: motor_ids
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motor_ids.size() == 0) {
      out << "motor_ids: []\n";
    } else {
      out << "motor_ids:\n";
      for (auto item : msg.motor_ids) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: target_positions
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.target_positions.size() == 0) {
      out << "target_positions: []\n";
    } else {
      out << "target_positions:\n";
      for (auto item : msg.target_positions) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: target_velocitie
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.target_velocitie.size() == 0) {
      out << "target_velocitie: []\n";
    } else {
      out << "target_velocitie:\n";
      for (auto item : msg.target_velocitie) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Robotarmcontrol & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace module_manager_hub

namespace rosidl_generator_traits
{

[[deprecated("use module_manager_hub::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const module_manager_hub::msg::Robotarmcontrol & msg,
  std::ostream & out, size_t indentation = 0)
{
  module_manager_hub::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use module_manager_hub::msg::to_yaml() instead")]]
inline std::string to_yaml(const module_manager_hub::msg::Robotarmcontrol & msg)
{
  return module_manager_hub::msg::to_yaml(msg);
}

template<>
inline const char * data_type<module_manager_hub::msg::Robotarmcontrol>()
{
  return "module_manager_hub::msg::Robotarmcontrol";
}

template<>
inline const char * name<module_manager_hub::msg::Robotarmcontrol>()
{
  return "module_manager_hub/msg/Robotarmcontrol";
}

template<>
struct has_fixed_size<module_manager_hub::msg::Robotarmcontrol>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<module_manager_hub::msg::Robotarmcontrol>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<module_manager_hub::msg::Robotarmcontrol>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__TRAITS_HPP_
