// generated from rosidl_generator_c/resource/idl.h.em
// with input from module_manager_hub:msg/ModuleStatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__MODULE_STATUS_H_
#define MODULE_MANAGER_HUB__MSG__MODULE_STATUS_H_

#include "module_manager_hub/msg/detail/module_status__struct.h"
#include "module_manager_hub/msg/detail/module_status__functions.h"
#include "module_manager_hub/msg/detail/module_status__type_support.h"

#endif  // MODULE_MANAGER_HUB__MSG__MODULE_STATUS_H_
