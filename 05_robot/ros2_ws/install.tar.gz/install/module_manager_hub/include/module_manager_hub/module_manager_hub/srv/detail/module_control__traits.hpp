// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from module_manager_hub:srv/ModuleControl.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__TRAITS_HPP_
#define MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "module_manager_hub/srv/detail/module_control__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace module_manager_hub
{

namespace srv
{

inline void to_flow_style_yaml(
  const ModuleControl_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: module_name
  {
    out << "module_name: ";
    rosidl_generator_traits::value_to_yaml(msg.module_name, out);
    out << ", ";
  }

  // member: cmd
  {
    out << "cmd: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ModuleControl_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: module_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "module_name: ";
    rosidl_generator_traits::value_to_yaml(msg.module_name, out);
    out << "\n";
  }

  // member: cmd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ModuleControl_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace module_manager_hub

namespace rosidl_generator_traits
{

[[deprecated("use module_manager_hub::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const module_manager_hub::srv::ModuleControl_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  module_manager_hub::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use module_manager_hub::srv::to_yaml() instead")]]
inline std::string to_yaml(const module_manager_hub::srv::ModuleControl_Request & msg)
{
  return module_manager_hub::srv::to_yaml(msg);
}

template<>
inline const char * data_type<module_manager_hub::srv::ModuleControl_Request>()
{
  return "module_manager_hub::srv::ModuleControl_Request";
}

template<>
inline const char * name<module_manager_hub::srv::ModuleControl_Request>()
{
  return "module_manager_hub/srv/ModuleControl_Request";
}

template<>
struct has_fixed_size<module_manager_hub::srv::ModuleControl_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<module_manager_hub::srv::ModuleControl_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<module_manager_hub::srv::ModuleControl_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace module_manager_hub
{

namespace srv
{

inline void to_flow_style_yaml(
  const ModuleControl_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ModuleControl_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ModuleControl_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace module_manager_hub

namespace rosidl_generator_traits
{

[[deprecated("use module_manager_hub::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const module_manager_hub::srv::ModuleControl_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  module_manager_hub::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use module_manager_hub::srv::to_yaml() instead")]]
inline std::string to_yaml(const module_manager_hub::srv::ModuleControl_Response & msg)
{
  return module_manager_hub::srv::to_yaml(msg);
}

template<>
inline const char * data_type<module_manager_hub::srv::ModuleControl_Response>()
{
  return "module_manager_hub::srv::ModuleControl_Response";
}

template<>
inline const char * name<module_manager_hub::srv::ModuleControl_Response>()
{
  return "module_manager_hub/srv/ModuleControl_Response";
}

template<>
struct has_fixed_size<module_manager_hub::srv::ModuleControl_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<module_manager_hub::srv::ModuleControl_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<module_manager_hub::srv::ModuleControl_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<module_manager_hub::srv::ModuleControl>()
{
  return "module_manager_hub::srv::ModuleControl";
}

template<>
inline const char * name<module_manager_hub::srv::ModuleControl>()
{
  return "module_manager_hub/srv/ModuleControl";
}

template<>
struct has_fixed_size<module_manager_hub::srv::ModuleControl>
  : std::integral_constant<
    bool,
    has_fixed_size<module_manager_hub::srv::ModuleControl_Request>::value &&
    has_fixed_size<module_manager_hub::srv::ModuleControl_Response>::value
  >
{
};

template<>
struct has_bounded_size<module_manager_hub::srv::ModuleControl>
  : std::integral_constant<
    bool,
    has_bounded_size<module_manager_hub::srv::ModuleControl_Request>::value &&
    has_bounded_size<module_manager_hub::srv::ModuleControl_Response>::value
  >
{
};

template<>
struct is_service<module_manager_hub::srv::ModuleControl>
  : std::true_type
{
};

template<>
struct is_service_request<module_manager_hub::srv::ModuleControl_Request>
  : std::true_type
{
};

template<>
struct is_service_response<module_manager_hub::srv::ModuleControl_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__TRAITS_HPP_
