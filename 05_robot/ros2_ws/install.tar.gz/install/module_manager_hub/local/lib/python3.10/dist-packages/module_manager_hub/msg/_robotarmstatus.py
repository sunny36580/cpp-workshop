# generated from rosidl_generator_py/resource/_idl.py.em
# with input from module_manager_hub:msg/Robotarmstatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

# Member 'motor_ids'
# Member 'actual_positions'
# Member 'actual_velocities'
import array  # noqa: E402, I100

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_Robotarmstatus(type):
    """Metaclass of message 'Robotarmstatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('module_manager_hub')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'module_manager_hub.msg.Robotarmstatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__robotarmstatus
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__robotarmstatus
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__robotarmstatus
            cls._TYPE_SUPPORT = module.type_support_msg__msg__robotarmstatus
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__robotarmstatus

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class Robotarmstatus(metaclass=Metaclass_Robotarmstatus):
    """Message class 'Robotarmstatus'."""

    __slots__ = [
        '_motor_ids',
        '_actual_positions',
        '_actual_velocities',
    ]

    _fields_and_field_types = {
        'motor_ids': 'sequence<uint32>',
        'actual_positions': 'sequence<float>',
        'actual_velocities': 'sequence<float>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('uint32')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.motor_ids = array.array('I', kwargs.get('motor_ids', []))
        self.actual_positions = array.array('f', kwargs.get('actual_positions', []))
        self.actual_velocities = array.array('f', kwargs.get('actual_velocities', []))

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.motor_ids != other.motor_ids:
            return False
        if self.actual_positions != other.actual_positions:
            return False
        if self.actual_velocities != other.actual_velocities:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def motor_ids(self):
        """Message field 'motor_ids'."""
        return self._motor_ids

    @motor_ids.setter
    def motor_ids(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'I', \
                "The 'motor_ids' array.array() must have the type code of 'I'"
            self._motor_ids = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, int) for v in value) and
                 all(val >= 0 and val < 4294967296 for val in value)), \
                "The 'motor_ids' field must be a set or sequence and each value of type 'int' and each unsigned integer in [0, 4294967295]"
        self._motor_ids = array.array('I', value)

    @builtins.property
    def actual_positions(self):
        """Message field 'actual_positions'."""
        return self._actual_positions

    @actual_positions.setter
    def actual_positions(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'actual_positions' array.array() must have the type code of 'f'"
            self._actual_positions = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'actual_positions' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._actual_positions = array.array('f', value)

    @builtins.property
    def actual_velocities(self):
        """Message field 'actual_velocities'."""
        return self._actual_velocities

    @actual_velocities.setter
    def actual_velocities(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'actual_velocities' array.array() must have the type code of 'f'"
            self._actual_velocities = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'actual_velocities' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._actual_velocities = array.array('f', value)
