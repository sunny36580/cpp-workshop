// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__ROBOTARMCONTROL_HPP_
#define MODULE_MANAGER_HUB__MSG__ROBOTARMCONTROL_HPP_

#include "module_manager_hub/msg/detail/robotarmcontrol__struct.hpp"
#include "module_manager_hub/msg/detail/robotarmcontrol__builder.hpp"
#include "module_manager_hub/msg/detail/robotarmcontrol__traits.hpp"
#include "module_manager_hub/msg/detail/robotarmcontrol__type_support.hpp"

#endif  // MODULE_MANAGER_HUB__MSG__ROBOTARMCONTROL_HPP_
