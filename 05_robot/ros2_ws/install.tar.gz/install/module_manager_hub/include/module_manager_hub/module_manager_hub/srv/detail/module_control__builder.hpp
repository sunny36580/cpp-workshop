// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from module_manager_hub:srv/ModuleControl.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__BUILDER_HPP_
#define MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "module_manager_hub/srv/detail/module_control__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace module_manager_hub
{

namespace srv
{

namespace builder
{

class Init_ModuleControl_Request_cmd
{
public:
  explicit Init_ModuleControl_Request_cmd(::module_manager_hub::srv::ModuleControl_Request & msg)
  : msg_(msg)
  {}
  ::module_manager_hub::srv::ModuleControl_Request cmd(::module_manager_hub::srv::ModuleControl_Request::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return std::move(msg_);
  }

private:
  ::module_manager_hub::srv::ModuleControl_Request msg_;
};

class Init_ModuleControl_Request_module_name
{
public:
  Init_ModuleControl_Request_module_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ModuleControl_Request_cmd module_name(::module_manager_hub::srv::ModuleControl_Request::_module_name_type arg)
  {
    msg_.module_name = std::move(arg);
    return Init_ModuleControl_Request_cmd(msg_);
  }

private:
  ::module_manager_hub::srv::ModuleControl_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::module_manager_hub::srv::ModuleControl_Request>()
{
  return module_manager_hub::srv::builder::Init_ModuleControl_Request_module_name();
}

}  // namespace module_manager_hub


namespace module_manager_hub
{

namespace srv
{

namespace builder
{

class Init_ModuleControl_Response_message
{
public:
  explicit Init_ModuleControl_Response_message(::module_manager_hub::srv::ModuleControl_Response & msg)
  : msg_(msg)
  {}
  ::module_manager_hub::srv::ModuleControl_Response message(::module_manager_hub::srv::ModuleControl_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::module_manager_hub::srv::ModuleControl_Response msg_;
};

class Init_ModuleControl_Response_success
{
public:
  Init_ModuleControl_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ModuleControl_Response_message success(::module_manager_hub::srv::ModuleControl_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_ModuleControl_Response_message(msg_);
  }

private:
  ::module_manager_hub::srv::ModuleControl_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::module_manager_hub::srv::ModuleControl_Response>()
{
  return module_manager_hub::srv::builder::Init_ModuleControl_Response_success();
}

}  // namespace module_manager_hub

#endif  // MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__BUILDER_HPP_
