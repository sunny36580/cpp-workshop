// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from module_manager_hub:msg/Robotarmstatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__TYPE_SUPPORT_H_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "module_manager_hub/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  module_manager_hub,
  msg,
  Robotarmstatus
)();

#ifdef __cplusplus
}
#endif

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__TYPE_SUPPORT_H_
