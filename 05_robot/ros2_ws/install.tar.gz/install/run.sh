COLCON_CURRENT_PREFIX=$PWD source setup.sh
ros2 launch module_manager_hub manager.launch.py