// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from module_manager_hub:msg/Robotarmstatus.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "module_manager_hub/msg/detail/robotarmstatus__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace module_manager_hub
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void Robotarmstatus_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) module_manager_hub::msg::Robotarmstatus(_init);
}

void Robotarmstatus_fini_function(void * message_memory)
{
  auto typed_message = static_cast<module_manager_hub::msg::Robotarmstatus *>(message_memory);
  typed_message->~Robotarmstatus();
}

size_t size_function__Robotarmstatus__motor_ids(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__Robotarmstatus__motor_ids(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__Robotarmstatus__motor_ids(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void fetch_function__Robotarmstatus__motor_ids(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint32_t *>(
    get_const_function__Robotarmstatus__motor_ids(untyped_member, index));
  auto & value = *reinterpret_cast<uint32_t *>(untyped_value);
  value = item;
}

void assign_function__Robotarmstatus__motor_ids(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint32_t *>(
    get_function__Robotarmstatus__motor_ids(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint32_t *>(untyped_value);
  item = value;
}

void resize_function__Robotarmstatus__motor_ids(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  member->resize(size);
}

size_t size_function__Robotarmstatus__actual_positions(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<float> *>(untyped_member);
  return member->size();
}

const void * get_const_function__Robotarmstatus__actual_positions(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<float> *>(untyped_member);
  return &member[index];
}

void * get_function__Robotarmstatus__actual_positions(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<float> *>(untyped_member);
  return &member[index];
}

void fetch_function__Robotarmstatus__actual_positions(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__Robotarmstatus__actual_positions(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__Robotarmstatus__actual_positions(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__Robotarmstatus__actual_positions(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

void resize_function__Robotarmstatus__actual_positions(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<float> *>(untyped_member);
  member->resize(size);
}

size_t size_function__Robotarmstatus__actual_velocities(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<float> *>(untyped_member);
  return member->size();
}

const void * get_const_function__Robotarmstatus__actual_velocities(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<float> *>(untyped_member);
  return &member[index];
}

void * get_function__Robotarmstatus__actual_velocities(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<float> *>(untyped_member);
  return &member[index];
}

void fetch_function__Robotarmstatus__actual_velocities(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__Robotarmstatus__actual_velocities(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__Robotarmstatus__actual_velocities(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__Robotarmstatus__actual_velocities(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

void resize_function__Robotarmstatus__actual_velocities(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<float> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember Robotarmstatus_message_member_array[3] = {
  {
    "motor_ids",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub::msg::Robotarmstatus, motor_ids),  // bytes offset in struct
    nullptr,  // default value
    size_function__Robotarmstatus__motor_ids,  // size() function pointer
    get_const_function__Robotarmstatus__motor_ids,  // get_const(index) function pointer
    get_function__Robotarmstatus__motor_ids,  // get(index) function pointer
    fetch_function__Robotarmstatus__motor_ids,  // fetch(index, &value) function pointer
    assign_function__Robotarmstatus__motor_ids,  // assign(index, value) function pointer
    resize_function__Robotarmstatus__motor_ids  // resize(index) function pointer
  },
  {
    "actual_positions",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub::msg::Robotarmstatus, actual_positions),  // bytes offset in struct
    nullptr,  // default value
    size_function__Robotarmstatus__actual_positions,  // size() function pointer
    get_const_function__Robotarmstatus__actual_positions,  // get_const(index) function pointer
    get_function__Robotarmstatus__actual_positions,  // get(index) function pointer
    fetch_function__Robotarmstatus__actual_positions,  // fetch(index, &value) function pointer
    assign_function__Robotarmstatus__actual_positions,  // assign(index, value) function pointer
    resize_function__Robotarmstatus__actual_positions  // resize(index) function pointer
  },
  {
    "actual_velocities",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(module_manager_hub::msg::Robotarmstatus, actual_velocities),  // bytes offset in struct
    nullptr,  // default value
    size_function__Robotarmstatus__actual_velocities,  // size() function pointer
    get_const_function__Robotarmstatus__actual_velocities,  // get_const(index) function pointer
    get_function__Robotarmstatus__actual_velocities,  // get(index) function pointer
    fetch_function__Robotarmstatus__actual_velocities,  // fetch(index, &value) function pointer
    assign_function__Robotarmstatus__actual_velocities,  // assign(index, value) function pointer
    resize_function__Robotarmstatus__actual_velocities  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers Robotarmstatus_message_members = {
  "module_manager_hub::msg",  // message namespace
  "Robotarmstatus",  // message name
  3,  // number of fields
  sizeof(module_manager_hub::msg::Robotarmstatus),
  Robotarmstatus_message_member_array,  // message members
  Robotarmstatus_init_function,  // function to initialize message memory (memory has to be allocated)
  Robotarmstatus_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t Robotarmstatus_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &Robotarmstatus_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace module_manager_hub


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<module_manager_hub::msg::Robotarmstatus>()
{
  return &::module_manager_hub::msg::rosidl_typesupport_introspection_cpp::Robotarmstatus_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, module_manager_hub, msg, Robotarmstatus)() {
  return &::module_manager_hub::msg::rosidl_typesupport_introspection_cpp::Robotarmstatus_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
