// generated from rosidl_generator_c/resource/idl.h.em
// with input from module_manager_hub:msg/Robotarmstatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__ROBOTARMSTATUS_H_
#define MODULE_MANAGER_HUB__MSG__ROBOTARMSTATUS_H_

#include "module_manager_hub/msg/detail/robotarmstatus__struct.h"
#include "module_manager_hub/msg/detail/robotarmstatus__functions.h"
#include "module_manager_hub/msg/detail/robotarmstatus__type_support.h"

#endif  // MODULE_MANAGER_HUB__MSG__ROBOTARMSTATUS_H_
