# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(module_manager_hub_IDL_FILES "msg/ModuleStatus.idl;msg/Robotarmcontrol.idl;msg/Robotarmstatus.idl;srv/ModuleControl.idl")
set(module_manager_hub_INTERFACE_FILES "msg/ModuleStatus.msg;msg/Robotarmcontrol.msg;msg/Robotarmstatus.msg;srv/ModuleControl.srv;srv/ModuleControl_Request.msg;srv/ModuleControl_Response.msg")
