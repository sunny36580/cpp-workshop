// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from module_manager_hub:msg/Robotarmcontrol.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__BUILDER_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "module_manager_hub/msg/detail/robotarmcontrol__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace module_manager_hub
{

namespace msg
{

namespace builder
{

class Init_Robotarmcontrol_target_velocitie
{
public:
  explicit Init_Robotarmcontrol_target_velocitie(::module_manager_hub::msg::Robotarmcontrol & msg)
  : msg_(msg)
  {}
  ::module_manager_hub::msg::Robotarmcontrol target_velocitie(::module_manager_hub::msg::Robotarmcontrol::_target_velocitie_type arg)
  {
    msg_.target_velocitie = std::move(arg);
    return std::move(msg_);
  }

private:
  ::module_manager_hub::msg::Robotarmcontrol msg_;
};

class Init_Robotarmcontrol_target_positions
{
public:
  explicit Init_Robotarmcontrol_target_positions(::module_manager_hub::msg::Robotarmcontrol & msg)
  : msg_(msg)
  {}
  Init_Robotarmcontrol_target_velocitie target_positions(::module_manager_hub::msg::Robotarmcontrol::_target_positions_type arg)
  {
    msg_.target_positions = std::move(arg);
    return Init_Robotarmcontrol_target_velocitie(msg_);
  }

private:
  ::module_manager_hub::msg::Robotarmcontrol msg_;
};

class Init_Robotarmcontrol_motor_ids
{
public:
  Init_Robotarmcontrol_motor_ids()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Robotarmcontrol_target_positions motor_ids(::module_manager_hub::msg::Robotarmcontrol::_motor_ids_type arg)
  {
    msg_.motor_ids = std::move(arg);
    return Init_Robotarmcontrol_target_positions(msg_);
  }

private:
  ::module_manager_hub::msg::Robotarmcontrol msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::module_manager_hub::msg::Robotarmcontrol>()
{
  return module_manager_hub::msg::builder::Init_Robotarmcontrol_motor_ids();
}

}  // namespace module_manager_hub

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__BUILDER_HPP_
