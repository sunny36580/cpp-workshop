// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from module_manager_hub:msg/Robotarmstatus.idl
// generated code does not contain a copyright notice
#include "module_manager_hub/msg/detail/robotarmstatus__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `motor_ids`
// Member `actual_positions`
// Member `actual_velocities`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
module_manager_hub__msg__Robotarmstatus__init(module_manager_hub__msg__Robotarmstatus * msg)
{
  if (!msg) {
    return false;
  }
  // motor_ids
  if (!rosidl_runtime_c__uint32__Sequence__init(&msg->motor_ids, 0)) {
    module_manager_hub__msg__Robotarmstatus__fini(msg);
    return false;
  }
  // actual_positions
  if (!rosidl_runtime_c__float__Sequence__init(&msg->actual_positions, 0)) {
    module_manager_hub__msg__Robotarmstatus__fini(msg);
    return false;
  }
  // actual_velocities
  if (!rosidl_runtime_c__float__Sequence__init(&msg->actual_velocities, 0)) {
    module_manager_hub__msg__Robotarmstatus__fini(msg);
    return false;
  }
  return true;
}

void
module_manager_hub__msg__Robotarmstatus__fini(module_manager_hub__msg__Robotarmstatus * msg)
{
  if (!msg) {
    return;
  }
  // motor_ids
  rosidl_runtime_c__uint32__Sequence__fini(&msg->motor_ids);
  // actual_positions
  rosidl_runtime_c__float__Sequence__fini(&msg->actual_positions);
  // actual_velocities
  rosidl_runtime_c__float__Sequence__fini(&msg->actual_velocities);
}

bool
module_manager_hub__msg__Robotarmstatus__are_equal(const module_manager_hub__msg__Robotarmstatus * lhs, const module_manager_hub__msg__Robotarmstatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // motor_ids
  if (!rosidl_runtime_c__uint32__Sequence__are_equal(
      &(lhs->motor_ids), &(rhs->motor_ids)))
  {
    return false;
  }
  // actual_positions
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->actual_positions), &(rhs->actual_positions)))
  {
    return false;
  }
  // actual_velocities
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->actual_velocities), &(rhs->actual_velocities)))
  {
    return false;
  }
  return true;
}

bool
module_manager_hub__msg__Robotarmstatus__copy(
  const module_manager_hub__msg__Robotarmstatus * input,
  module_manager_hub__msg__Robotarmstatus * output)
{
  if (!input || !output) {
    return false;
  }
  // motor_ids
  if (!rosidl_runtime_c__uint32__Sequence__copy(
      &(input->motor_ids), &(output->motor_ids)))
  {
    return false;
  }
  // actual_positions
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->actual_positions), &(output->actual_positions)))
  {
    return false;
  }
  // actual_velocities
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->actual_velocities), &(output->actual_velocities)))
  {
    return false;
  }
  return true;
}

module_manager_hub__msg__Robotarmstatus *
module_manager_hub__msg__Robotarmstatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__msg__Robotarmstatus * msg = (module_manager_hub__msg__Robotarmstatus *)allocator.allocate(sizeof(module_manager_hub__msg__Robotarmstatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(module_manager_hub__msg__Robotarmstatus));
  bool success = module_manager_hub__msg__Robotarmstatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
module_manager_hub__msg__Robotarmstatus__destroy(module_manager_hub__msg__Robotarmstatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    module_manager_hub__msg__Robotarmstatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
module_manager_hub__msg__Robotarmstatus__Sequence__init(module_manager_hub__msg__Robotarmstatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__msg__Robotarmstatus * data = NULL;

  if (size) {
    data = (module_manager_hub__msg__Robotarmstatus *)allocator.zero_allocate(size, sizeof(module_manager_hub__msg__Robotarmstatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = module_manager_hub__msg__Robotarmstatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        module_manager_hub__msg__Robotarmstatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
module_manager_hub__msg__Robotarmstatus__Sequence__fini(module_manager_hub__msg__Robotarmstatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      module_manager_hub__msg__Robotarmstatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

module_manager_hub__msg__Robotarmstatus__Sequence *
module_manager_hub__msg__Robotarmstatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__msg__Robotarmstatus__Sequence * array = (module_manager_hub__msg__Robotarmstatus__Sequence *)allocator.allocate(sizeof(module_manager_hub__msg__Robotarmstatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = module_manager_hub__msg__Robotarmstatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
module_manager_hub__msg__Robotarmstatus__Sequence__destroy(module_manager_hub__msg__Robotarmstatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    module_manager_hub__msg__Robotarmstatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
module_manager_hub__msg__Robotarmstatus__Sequence__are_equal(const module_manager_hub__msg__Robotarmstatus__Sequence * lhs, const module_manager_hub__msg__Robotarmstatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!module_manager_hub__msg__Robotarmstatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
module_manager_hub__msg__Robotarmstatus__Sequence__copy(
  const module_manager_hub__msg__Robotarmstatus__Sequence * input,
  module_manager_hub__msg__Robotarmstatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(module_manager_hub__msg__Robotarmstatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    module_manager_hub__msg__Robotarmstatus * data =
      (module_manager_hub__msg__Robotarmstatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!module_manager_hub__msg__Robotarmstatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          module_manager_hub__msg__Robotarmstatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!module_manager_hub__msg__Robotarmstatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
