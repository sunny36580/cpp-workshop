// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from module_manager_hub:msg/Robotarmcontrol.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__FUNCTIONS_H_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "module_manager_hub/msg/rosidl_generator_c__visibility_control.h"

#include "module_manager_hub/msg/detail/robotarmcontrol__struct.h"

/// Initialize msg/Robotarmcontrol message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * module_manager_hub__msg__Robotarmcontrol
 * )) before or use
 * module_manager_hub__msg__Robotarmcontrol__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
bool
module_manager_hub__msg__Robotarmcontrol__init(module_manager_hub__msg__Robotarmcontrol * msg);

/// Finalize msg/Robotarmcontrol message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
void
module_manager_hub__msg__Robotarmcontrol__fini(module_manager_hub__msg__Robotarmcontrol * msg);

/// Create msg/Robotarmcontrol message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * module_manager_hub__msg__Robotarmcontrol__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
module_manager_hub__msg__Robotarmcontrol *
module_manager_hub__msg__Robotarmcontrol__create();

/// Destroy msg/Robotarmcontrol message.
/**
 * It calls
 * module_manager_hub__msg__Robotarmcontrol__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
void
module_manager_hub__msg__Robotarmcontrol__destroy(module_manager_hub__msg__Robotarmcontrol * msg);

/// Check for msg/Robotarmcontrol message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
bool
module_manager_hub__msg__Robotarmcontrol__are_equal(const module_manager_hub__msg__Robotarmcontrol * lhs, const module_manager_hub__msg__Robotarmcontrol * rhs);

/// Copy a msg/Robotarmcontrol message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
bool
module_manager_hub__msg__Robotarmcontrol__copy(
  const module_manager_hub__msg__Robotarmcontrol * input,
  module_manager_hub__msg__Robotarmcontrol * output);

/// Initialize array of msg/Robotarmcontrol messages.
/**
 * It allocates the memory for the number of elements and calls
 * module_manager_hub__msg__Robotarmcontrol__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
bool
module_manager_hub__msg__Robotarmcontrol__Sequence__init(module_manager_hub__msg__Robotarmcontrol__Sequence * array, size_t size);

/// Finalize array of msg/Robotarmcontrol messages.
/**
 * It calls
 * module_manager_hub__msg__Robotarmcontrol__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
void
module_manager_hub__msg__Robotarmcontrol__Sequence__fini(module_manager_hub__msg__Robotarmcontrol__Sequence * array);

/// Create array of msg/Robotarmcontrol messages.
/**
 * It allocates the memory for the array and calls
 * module_manager_hub__msg__Robotarmcontrol__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
module_manager_hub__msg__Robotarmcontrol__Sequence *
module_manager_hub__msg__Robotarmcontrol__Sequence__create(size_t size);

/// Destroy array of msg/Robotarmcontrol messages.
/**
 * It calls
 * module_manager_hub__msg__Robotarmcontrol__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
void
module_manager_hub__msg__Robotarmcontrol__Sequence__destroy(module_manager_hub__msg__Robotarmcontrol__Sequence * array);

/// Check for msg/Robotarmcontrol message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
bool
module_manager_hub__msg__Robotarmcontrol__Sequence__are_equal(const module_manager_hub__msg__Robotarmcontrol__Sequence * lhs, const module_manager_hub__msg__Robotarmcontrol__Sequence * rhs);

/// Copy an array of msg/Robotarmcontrol messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_module_manager_hub
bool
module_manager_hub__msg__Robotarmcontrol__Sequence__copy(
  const module_manager_hub__msg__Robotarmcontrol__Sequence * input,
  module_manager_hub__msg__Robotarmcontrol__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMCONTROL__FUNCTIONS_H_
