// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from module_manager_hub:srv/ModuleControl.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__STRUCT_HPP_
#define MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__module_manager_hub__srv__ModuleControl_Request __attribute__((deprecated))
#else
# define DEPRECATED__module_manager_hub__srv__ModuleControl_Request __declspec(deprecated)
#endif

namespace module_manager_hub
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct ModuleControl_Request_
{
  using Type = ModuleControl_Request_<ContainerAllocator>;

  explicit ModuleControl_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->module_name = "";
      this->cmd = 0;
    }
  }

  explicit ModuleControl_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : module_name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->module_name = "";
      this->cmd = 0;
    }
  }

  // field types and members
  using _module_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _module_name_type module_name;
  using _cmd_type =
    uint8_t;
  _cmd_type cmd;

  // setters for named parameter idiom
  Type & set__module_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->module_name = _arg;
    return *this;
  }
  Type & set__cmd(
    const uint8_t & _arg)
  {
    this->cmd = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__module_manager_hub__srv__ModuleControl_Request
    std::shared_ptr<module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__module_manager_hub__srv__ModuleControl_Request
    std::shared_ptr<module_manager_hub::srv::ModuleControl_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ModuleControl_Request_ & other) const
  {
    if (this->module_name != other.module_name) {
      return false;
    }
    if (this->cmd != other.cmd) {
      return false;
    }
    return true;
  }
  bool operator!=(const ModuleControl_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ModuleControl_Request_

// alias to use template instance with default allocator
using ModuleControl_Request =
  module_manager_hub::srv::ModuleControl_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace module_manager_hub


#ifndef _WIN32
# define DEPRECATED__module_manager_hub__srv__ModuleControl_Response __attribute__((deprecated))
#else
# define DEPRECATED__module_manager_hub__srv__ModuleControl_Response __declspec(deprecated)
#endif

namespace module_manager_hub
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct ModuleControl_Response_
{
  using Type = ModuleControl_Response_<ContainerAllocator>;

  explicit ModuleControl_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  explicit ModuleControl_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__module_manager_hub__srv__ModuleControl_Response
    std::shared_ptr<module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__module_manager_hub__srv__ModuleControl_Response
    std::shared_ptr<module_manager_hub::srv::ModuleControl_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ModuleControl_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const ModuleControl_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ModuleControl_Response_

// alias to use template instance with default allocator
using ModuleControl_Response =
  module_manager_hub::srv::ModuleControl_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace module_manager_hub

namespace module_manager_hub
{

namespace srv
{

struct ModuleControl
{
  using Request = module_manager_hub::srv::ModuleControl_Request;
  using Response = module_manager_hub::srv::ModuleControl_Response;
};

}  // namespace srv

}  // namespace module_manager_hub

#endif  // MODULE_MANAGER_HUB__SRV__DETAIL__MODULE_CONTROL__STRUCT_HPP_
