// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from module_manager_hub:msg/Robotarmstatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__TRAITS_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "module_manager_hub/msg/detail/robotarmstatus__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace module_manager_hub
{

namespace msg
{

inline void to_flow_style_yaml(
  const Robotarmstatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: motor_ids
  {
    if (msg.motor_ids.size() == 0) {
      out << "motor_ids: []";
    } else {
      out << "motor_ids: [";
      size_t pending_items = msg.motor_ids.size();
      for (auto item : msg.motor_ids) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: actual_positions
  {
    if (msg.actual_positions.size() == 0) {
      out << "actual_positions: []";
    } else {
      out << "actual_positions: [";
      size_t pending_items = msg.actual_positions.size();
      for (auto item : msg.actual_positions) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: actual_velocities
  {
    if (msg.actual_velocities.size() == 0) {
      out << "actual_velocities: []";
    } else {
      out << "actual_velocities: [";
      size_t pending_items = msg.actual_velocities.size();
      for (auto item : msg.actual_velocities) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Robotarmstatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: motor_ids
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motor_ids.size() == 0) {
      out << "motor_ids: []\n";
    } else {
      out << "motor_ids:\n";
      for (auto item : msg.motor_ids) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: actual_positions
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.actual_positions.size() == 0) {
      out << "actual_positions: []\n";
    } else {
      out << "actual_positions:\n";
      for (auto item : msg.actual_positions) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: actual_velocities
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.actual_velocities.size() == 0) {
      out << "actual_velocities: []\n";
    } else {
      out << "actual_velocities:\n";
      for (auto item : msg.actual_velocities) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Robotarmstatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace module_manager_hub

namespace rosidl_generator_traits
{

[[deprecated("use module_manager_hub::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const module_manager_hub::msg::Robotarmstatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  module_manager_hub::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use module_manager_hub::msg::to_yaml() instead")]]
inline std::string to_yaml(const module_manager_hub::msg::Robotarmstatus & msg)
{
  return module_manager_hub::msg::to_yaml(msg);
}

template<>
inline const char * data_type<module_manager_hub::msg::Robotarmstatus>()
{
  return "module_manager_hub::msg::Robotarmstatus";
}

template<>
inline const char * name<module_manager_hub::msg::Robotarmstatus>()
{
  return "module_manager_hub/msg/Robotarmstatus";
}

template<>
struct has_fixed_size<module_manager_hub::msg::Robotarmstatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<module_manager_hub::msg::Robotarmstatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<module_manager_hub::msg::Robotarmstatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__TRAITS_HPP_
