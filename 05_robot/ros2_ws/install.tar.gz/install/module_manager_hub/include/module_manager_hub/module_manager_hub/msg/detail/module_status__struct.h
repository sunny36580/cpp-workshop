// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from module_manager_hub:msg/ModuleStatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__STRUCT_H_
#define MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
// Member 'state_msg'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/ModuleStatus in the package module_manager_hub.
typedef struct module_manager_hub__msg__ModuleStatus
{
  rosidl_runtime_c__String name;
  bool online;
  bool running;
  double last_heartbeat;
  rosidl_runtime_c__String state_msg;
} module_manager_hub__msg__ModuleStatus;

// Struct for a sequence of module_manager_hub__msg__ModuleStatus.
typedef struct module_manager_hub__msg__ModuleStatus__Sequence
{
  module_manager_hub__msg__ModuleStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} module_manager_hub__msg__ModuleStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__STRUCT_H_
