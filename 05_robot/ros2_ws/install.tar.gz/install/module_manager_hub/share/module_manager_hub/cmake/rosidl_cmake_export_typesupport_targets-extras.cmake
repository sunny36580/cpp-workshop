# generated from
# rosidl_cmake/cmake/template/rosidl_cmake_export_typesupport_targets.cmake.in

set(_exported_typesupport_targets
  "__rosidl_generator_c:module_manager_hub__rosidl_generator_c;__rosidl_typesupport_fastrtps_c:module_manager_hub__rosidl_typesupport_fastrtps_c;__rosidl_generator_cpp:module_manager_hub__rosidl_generator_cpp;__rosidl_typesupport_fastrtps_cpp:module_manager_hub__rosidl_typesupport_fastrtps_cpp;__rosidl_typesupport_introspection_c:module_manager_hub__rosidl_typesupport_introspection_c;__rosidl_typesupport_c:module_manager_hub__rosidl_typesupport_c;__rosidl_typesupport_introspection_cpp:module_manager_hub__rosidl_typesupport_introspection_cpp;__rosidl_typesupport_cpp:module_manager_hub__rosidl_typesupport_cpp;__rosidl_generator_py:module_manager_hub__rosidl_generator_py")

# populate module_manager_hub_TARGETS_<suffix>
if(NOT _exported_typesupport_targets STREQUAL "")
  # loop over typesupport targets
  foreach(_tuple ${_exported_typesupport_targets})
    string(REPLACE ":" ";" _tuple "${_tuple}")
    list(GET _tuple 0 _suffix)
    list(GET _tuple 1 _target)

    set(_target "module_manager_hub::${_target}")
    if(NOT TARGET "${_target}")
      # the exported target must exist
      message(WARNING "Package 'module_manager_hub' exports the typesupport target '${_target}' which doesn't exist")
    else()
      list(APPEND module_manager_hub_TARGETS${_suffix} "${_target}")
    endif()
  endforeach()
endif()
