// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from module_manager_hub:msg/Robotarmstatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__STRUCT_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__module_manager_hub__msg__Robotarmstatus __attribute__((deprecated))
#else
# define DEPRECATED__module_manager_hub__msg__Robotarmstatus __declspec(deprecated)
#endif

namespace module_manager_hub
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Robotarmstatus_
{
  using Type = Robotarmstatus_<ContainerAllocator>;

  explicit Robotarmstatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
  }

  explicit Robotarmstatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
    (void)_alloc;
  }

  // field types and members
  using _motor_ids_type =
    std::vector<uint32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint32_t>>;
  _motor_ids_type motor_ids;
  using _actual_positions_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _actual_positions_type actual_positions;
  using _actual_velocities_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _actual_velocities_type actual_velocities;

  // setters for named parameter idiom
  Type & set__motor_ids(
    const std::vector<uint32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint32_t>> & _arg)
  {
    this->motor_ids = _arg;
    return *this;
  }
  Type & set__actual_positions(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->actual_positions = _arg;
    return *this;
  }
  Type & set__actual_velocities(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->actual_velocities = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    module_manager_hub::msg::Robotarmstatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const module_manager_hub::msg::Robotarmstatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<module_manager_hub::msg::Robotarmstatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<module_manager_hub::msg::Robotarmstatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::msg::Robotarmstatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::msg::Robotarmstatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::msg::Robotarmstatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::msg::Robotarmstatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<module_manager_hub::msg::Robotarmstatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<module_manager_hub::msg::Robotarmstatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__module_manager_hub__msg__Robotarmstatus
    std::shared_ptr<module_manager_hub::msg::Robotarmstatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__module_manager_hub__msg__Robotarmstatus
    std::shared_ptr<module_manager_hub::msg::Robotarmstatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Robotarmstatus_ & other) const
  {
    if (this->motor_ids != other.motor_ids) {
      return false;
    }
    if (this->actual_positions != other.actual_positions) {
      return false;
    }
    if (this->actual_velocities != other.actual_velocities) {
      return false;
    }
    return true;
  }
  bool operator!=(const Robotarmstatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Robotarmstatus_

// alias to use template instance with default allocator
using Robotarmstatus =
  module_manager_hub::msg::Robotarmstatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace module_manager_hub

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__STRUCT_HPP_
