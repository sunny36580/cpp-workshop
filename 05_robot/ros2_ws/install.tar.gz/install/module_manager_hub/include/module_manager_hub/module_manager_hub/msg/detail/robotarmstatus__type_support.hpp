// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from module_manager_hub:msg/Robotarmstatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__TYPE_SUPPORT_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "module_manager_hub/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_module_manager_hub
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  module_manager_hub,
  msg,
  Robotarmstatus
)();
#ifdef __cplusplus
}
#endif

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__ROBOTARMSTATUS__TYPE_SUPPORT_HPP_
