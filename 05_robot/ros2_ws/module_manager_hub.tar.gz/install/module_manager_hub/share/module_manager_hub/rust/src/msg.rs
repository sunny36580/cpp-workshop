#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to module_manager_hub__msg__ModuleStatus

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ModuleStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub name: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub online: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub running: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub last_heartbeat: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub state_msg: std::string::String,

}



impl Default for ModuleStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ModuleStatus::default())
  }
}

impl rosidl_runtime_rs::Message for ModuleStatus {
  type RmwMsg = super::msg::rmw::ModuleStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        name: msg.name.as_str().into(),
        online: msg.online,
        running: msg.running,
        last_heartbeat: msg.last_heartbeat,
        state_msg: msg.state_msg.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        name: msg.name.as_str().into(),
      online: msg.online,
      running: msg.running,
      last_heartbeat: msg.last_heartbeat,
        state_msg: msg.state_msg.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      name: msg.name.to_string(),
      online: msg.online,
      running: msg.running,
      last_heartbeat: msg.last_heartbeat,
      state_msg: msg.state_msg.to_string(),
    }
  }
}


// Corresponds to module_manager_hub__msg__Robotarmcontrol
/// 机械臂控制消息

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Robotarmcontrol {

    // This member is not documented.
    #[allow(missing_docs)]
    pub motor_ids: Vec<u32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_positions: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_velocitie: Vec<f32>,

}



impl Default for Robotarmcontrol {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Robotarmcontrol::default())
  }
}

impl rosidl_runtime_rs::Message for Robotarmcontrol {
  type RmwMsg = super::msg::rmw::Robotarmcontrol;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        motor_ids: msg.motor_ids.into(),
        target_positions: msg.target_positions.into(),
        target_velocitie: msg.target_velocitie.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        motor_ids: msg.motor_ids.as_slice().into(),
        target_positions: msg.target_positions.as_slice().into(),
        target_velocitie: msg.target_velocitie.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      motor_ids: msg.motor_ids
          .into_iter()
          .collect(),
      target_positions: msg.target_positions
          .into_iter()
          .collect(),
      target_velocitie: msg.target_velocitie
          .into_iter()
          .collect(),
    }
  }
}


// Corresponds to module_manager_hub__msg__Robotarmstatus
/// 机械臂状态消息

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Robotarmstatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub motor_ids: Vec<u32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_positions: Vec<f32>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub actual_velocities: Vec<f32>,

}



impl Default for Robotarmstatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Robotarmstatus::default())
  }
}

impl rosidl_runtime_rs::Message for Robotarmstatus {
  type RmwMsg = super::msg::rmw::Robotarmstatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        motor_ids: msg.motor_ids.into(),
        actual_positions: msg.actual_positions.into(),
        actual_velocities: msg.actual_velocities.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        motor_ids: msg.motor_ids.as_slice().into(),
        actual_positions: msg.actual_positions.as_slice().into(),
        actual_velocities: msg.actual_velocities.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      motor_ids: msg.motor_ids
          .into_iter()
          .collect(),
      actual_positions: msg.actual_positions
          .into_iter()
          .collect(),
      actual_velocities: msg.actual_velocities
          .into_iter()
          .collect(),
    }
  }
}


