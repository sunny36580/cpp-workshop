# generated from rosidl_generator_py/resource/_idl.py.em
# with input from module_manager_hub:msg/ModuleStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_ModuleStatus(type):
    """Metaclass of message 'ModuleStatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('module_manager_hub')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'module_manager_hub.msg.ModuleStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__module_status
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__module_status
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__module_status
            cls._TYPE_SUPPORT = module.type_support_msg__msg__module_status
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__module_status

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class ModuleStatus(metaclass=Metaclass_ModuleStatus):
    """Message class 'ModuleStatus'."""

    __slots__ = [
        '_name',
        '_online',
        '_running',
        '_last_heartbeat',
        '_state_msg',
    ]

    _fields_and_field_types = {
        'name': 'string',
        'online': 'boolean',
        'running': 'boolean',
        'last_heartbeat': 'double',
        'state_msg': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.name = kwargs.get('name', str())
        self.online = kwargs.get('online', bool())
        self.running = kwargs.get('running', bool())
        self.last_heartbeat = kwargs.get('last_heartbeat', float())
        self.state_msg = kwargs.get('state_msg', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.name != other.name:
            return False
        if self.online != other.online:
            return False
        if self.running != other.running:
            return False
        if self.last_heartbeat != other.last_heartbeat:
            return False
        if self.state_msg != other.state_msg:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def name(self):
        """Message field 'name'."""
        return self._name

    @name.setter
    def name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'name' field must be of type 'str'"
        self._name = value

    @builtins.property
    def online(self):
        """Message field 'online'."""
        return self._online

    @online.setter
    def online(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'online' field must be of type 'bool'"
        self._online = value

    @builtins.property
    def running(self):
        """Message field 'running'."""
        return self._running

    @running.setter
    def running(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'running' field must be of type 'bool'"
        self._running = value

    @builtins.property
    def last_heartbeat(self):
        """Message field 'last_heartbeat'."""
        return self._last_heartbeat

    @last_heartbeat.setter
    def last_heartbeat(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'last_heartbeat' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'last_heartbeat' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._last_heartbeat = value

    @builtins.property
    def state_msg(self):
        """Message field 'state_msg'."""
        return self._state_msg

    @state_msg.setter
    def state_msg(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'state_msg' field must be of type 'str'"
        self._state_msg = value
