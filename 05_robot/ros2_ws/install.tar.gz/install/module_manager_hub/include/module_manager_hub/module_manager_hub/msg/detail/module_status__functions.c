// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from module_manager_hub:msg/ModuleStatus.idl
// generated code does not contain a copyright notice
#include "module_manager_hub/msg/detail/module_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `name`
// Member `state_msg`
#include "rosidl_runtime_c/string_functions.h"

bool
module_manager_hub__msg__ModuleStatus__init(module_manager_hub__msg__ModuleStatus * msg)
{
  if (!msg) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__init(&msg->name)) {
    module_manager_hub__msg__ModuleStatus__fini(msg);
    return false;
  }
  // online
  // running
  // last_heartbeat
  // state_msg
  if (!rosidl_runtime_c__String__init(&msg->state_msg)) {
    module_manager_hub__msg__ModuleStatus__fini(msg);
    return false;
  }
  return true;
}

void
module_manager_hub__msg__ModuleStatus__fini(module_manager_hub__msg__ModuleStatus * msg)
{
  if (!msg) {
    return;
  }
  // name
  rosidl_runtime_c__String__fini(&msg->name);
  // online
  // running
  // last_heartbeat
  // state_msg
  rosidl_runtime_c__String__fini(&msg->state_msg);
}

bool
module_manager_hub__msg__ModuleStatus__are_equal(const module_manager_hub__msg__ModuleStatus * lhs, const module_manager_hub__msg__ModuleStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // online
  if (lhs->online != rhs->online) {
    return false;
  }
  // running
  if (lhs->running != rhs->running) {
    return false;
  }
  // last_heartbeat
  if (lhs->last_heartbeat != rhs->last_heartbeat) {
    return false;
  }
  // state_msg
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->state_msg), &(rhs->state_msg)))
  {
    return false;
  }
  return true;
}

bool
module_manager_hub__msg__ModuleStatus__copy(
  const module_manager_hub__msg__ModuleStatus * input,
  module_manager_hub__msg__ModuleStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // online
  output->online = input->online;
  // running
  output->running = input->running;
  // last_heartbeat
  output->last_heartbeat = input->last_heartbeat;
  // state_msg
  if (!rosidl_runtime_c__String__copy(
      &(input->state_msg), &(output->state_msg)))
  {
    return false;
  }
  return true;
}

module_manager_hub__msg__ModuleStatus *
module_manager_hub__msg__ModuleStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__msg__ModuleStatus * msg = (module_manager_hub__msg__ModuleStatus *)allocator.allocate(sizeof(module_manager_hub__msg__ModuleStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(module_manager_hub__msg__ModuleStatus));
  bool success = module_manager_hub__msg__ModuleStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
module_manager_hub__msg__ModuleStatus__destroy(module_manager_hub__msg__ModuleStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    module_manager_hub__msg__ModuleStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
module_manager_hub__msg__ModuleStatus__Sequence__init(module_manager_hub__msg__ModuleStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__msg__ModuleStatus * data = NULL;

  if (size) {
    data = (module_manager_hub__msg__ModuleStatus *)allocator.zero_allocate(size, sizeof(module_manager_hub__msg__ModuleStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = module_manager_hub__msg__ModuleStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        module_manager_hub__msg__ModuleStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
module_manager_hub__msg__ModuleStatus__Sequence__fini(module_manager_hub__msg__ModuleStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      module_manager_hub__msg__ModuleStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

module_manager_hub__msg__ModuleStatus__Sequence *
module_manager_hub__msg__ModuleStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  module_manager_hub__msg__ModuleStatus__Sequence * array = (module_manager_hub__msg__ModuleStatus__Sequence *)allocator.allocate(sizeof(module_manager_hub__msg__ModuleStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = module_manager_hub__msg__ModuleStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
module_manager_hub__msg__ModuleStatus__Sequence__destroy(module_manager_hub__msg__ModuleStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    module_manager_hub__msg__ModuleStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
module_manager_hub__msg__ModuleStatus__Sequence__are_equal(const module_manager_hub__msg__ModuleStatus__Sequence * lhs, const module_manager_hub__msg__ModuleStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!module_manager_hub__msg__ModuleStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
module_manager_hub__msg__ModuleStatus__Sequence__copy(
  const module_manager_hub__msg__ModuleStatus__Sequence * input,
  module_manager_hub__msg__ModuleStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(module_manager_hub__msg__ModuleStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    module_manager_hub__msg__ModuleStatus * data =
      (module_manager_hub__msg__ModuleStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!module_manager_hub__msg__ModuleStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          module_manager_hub__msg__ModuleStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!module_manager_hub__msg__ModuleStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
