// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from module_manager_hub:msg/ModuleStatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__STRUCT_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__module_manager_hub__msg__ModuleStatus __attribute__((deprecated))
#else
# define DEPRECATED__module_manager_hub__msg__ModuleStatus __declspec(deprecated)
#endif

namespace module_manager_hub
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ModuleStatus_
{
  using Type = ModuleStatus_<ContainerAllocator>;

  explicit ModuleStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->online = false;
      this->running = false;
      this->last_heartbeat = 0.0;
      this->state_msg = "";
    }
  }

  explicit ModuleStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : name(_alloc),
    state_msg(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->online = false;
      this->running = false;
      this->last_heartbeat = 0.0;
      this->state_msg = "";
    }
  }

  // field types and members
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _online_type =
    bool;
  _online_type online;
  using _running_type =
    bool;
  _running_type running;
  using _last_heartbeat_type =
    double;
  _last_heartbeat_type last_heartbeat;
  using _state_msg_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _state_msg_type state_msg;

  // setters for named parameter idiom
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__online(
    const bool & _arg)
  {
    this->online = _arg;
    return *this;
  }
  Type & set__running(
    const bool & _arg)
  {
    this->running = _arg;
    return *this;
  }
  Type & set__last_heartbeat(
    const double & _arg)
  {
    this->last_heartbeat = _arg;
    return *this;
  }
  Type & set__state_msg(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->state_msg = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    module_manager_hub::msg::ModuleStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const module_manager_hub::msg::ModuleStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<module_manager_hub::msg::ModuleStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<module_manager_hub::msg::ModuleStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::msg::ModuleStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::msg::ModuleStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      module_manager_hub::msg::ModuleStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<module_manager_hub::msg::ModuleStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<module_manager_hub::msg::ModuleStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<module_manager_hub::msg::ModuleStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__module_manager_hub__msg__ModuleStatus
    std::shared_ptr<module_manager_hub::msg::ModuleStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__module_manager_hub__msg__ModuleStatus
    std::shared_ptr<module_manager_hub::msg::ModuleStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ModuleStatus_ & other) const
  {
    if (this->name != other.name) {
      return false;
    }
    if (this->online != other.online) {
      return false;
    }
    if (this->running != other.running) {
      return false;
    }
    if (this->last_heartbeat != other.last_heartbeat) {
      return false;
    }
    if (this->state_msg != other.state_msg) {
      return false;
    }
    return true;
  }
  bool operator!=(const ModuleStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ModuleStatus_

// alias to use template instance with default allocator
using ModuleStatus =
  module_manager_hub::msg::ModuleStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace module_manager_hub

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__STRUCT_HPP_
