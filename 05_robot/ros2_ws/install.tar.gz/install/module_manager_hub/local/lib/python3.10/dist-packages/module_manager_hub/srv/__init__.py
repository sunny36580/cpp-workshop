from module_manager_hub.srv._module_control import ModuleControl  # noqa: F401
