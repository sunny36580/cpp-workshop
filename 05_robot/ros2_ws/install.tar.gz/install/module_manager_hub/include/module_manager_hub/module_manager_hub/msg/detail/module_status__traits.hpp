// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from module_manager_hub:msg/ModuleStatus.idl
// generated code does not contain a copyright notice

#ifndef MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__TRAITS_HPP_
#define MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "module_manager_hub/msg/detail/module_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace module_manager_hub
{

namespace msg
{

inline void to_flow_style_yaml(
  const ModuleStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: name
  {
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << ", ";
  }

  // member: online
  {
    out << "online: ";
    rosidl_generator_traits::value_to_yaml(msg.online, out);
    out << ", ";
  }

  // member: running
  {
    out << "running: ";
    rosidl_generator_traits::value_to_yaml(msg.running, out);
    out << ", ";
  }

  // member: last_heartbeat
  {
    out << "last_heartbeat: ";
    rosidl_generator_traits::value_to_yaml(msg.last_heartbeat, out);
    out << ", ";
  }

  // member: state_msg
  {
    out << "state_msg: ";
    rosidl_generator_traits::value_to_yaml(msg.state_msg, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ModuleStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << "\n";
  }

  // member: online
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "online: ";
    rosidl_generator_traits::value_to_yaml(msg.online, out);
    out << "\n";
  }

  // member: running
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "running: ";
    rosidl_generator_traits::value_to_yaml(msg.running, out);
    out << "\n";
  }

  // member: last_heartbeat
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "last_heartbeat: ";
    rosidl_generator_traits::value_to_yaml(msg.last_heartbeat, out);
    out << "\n";
  }

  // member: state_msg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "state_msg: ";
    rosidl_generator_traits::value_to_yaml(msg.state_msg, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ModuleStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace module_manager_hub

namespace rosidl_generator_traits
{

[[deprecated("use module_manager_hub::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const module_manager_hub::msg::ModuleStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  module_manager_hub::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use module_manager_hub::msg::to_yaml() instead")]]
inline std::string to_yaml(const module_manager_hub::msg::ModuleStatus & msg)
{
  return module_manager_hub::msg::to_yaml(msg);
}

template<>
inline const char * data_type<module_manager_hub::msg::ModuleStatus>()
{
  return "module_manager_hub::msg::ModuleStatus";
}

template<>
inline const char * name<module_manager_hub::msg::ModuleStatus>()
{
  return "module_manager_hub/msg/ModuleStatus";
}

template<>
struct has_fixed_size<module_manager_hub::msg::ModuleStatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<module_manager_hub::msg::ModuleStatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<module_manager_hub::msg::ModuleStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // MODULE_MANAGER_HUB__MSG__DETAIL__MODULE_STATUS__TRAITS_HPP_
